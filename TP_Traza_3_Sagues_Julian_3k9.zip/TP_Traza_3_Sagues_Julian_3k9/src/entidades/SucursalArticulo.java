package entidades;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class SucursalArticulo {
    private Long id;
    private Sucursal sucursal;
    private Articulo articulo;

    private Integer stock;
    private Double precioLocal;
    private Boolean activo;
    private String observaciones;

    public void setId(Long id) {
        this.id = id;
    }
}
