import entidades.*;
import repositorios.InMemoryRepository;

import java.time.LocalTime;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        /**Repositorios**/
        InMemoryRepository<Empresa> empresaRepo = new InMemoryRepository<>();
        InMemoryRepository<Sucursal> sucursalRepo = new InMemoryRepository<>();
        InMemoryRepository<SucursalArticulo> sucursalArticuloRepo = new InMemoryRepository<>();
        InMemoryRepository<Categoria> categoriaRepo = new InMemoryRepository<>();
        InMemoryRepository<ArticuloInsumo> insumoRepo = new InMemoryRepository<>();
        InMemoryRepository<ArticuloManufacturado> manufacturadoRepo = new InMemoryRepository<>();
        InMemoryRepository<UnidadMedida> unidadRepo = new InMemoryRepository<>();

        /**Geografía**/
        Pais argentina = Pais.builder().id(1L).nombre("Argentina").build();
        Provincia buenosAires = Provincia.builder().id(2L).nombre("Buenos Aires").pais(argentina).build();
        Provincia cordoba = Provincia.builder().id(3L).nombre("Córdoba").pais(argentina).build();

        Localidad caba = Localidad.builder().id(4L).nombre("CABA").provincia(buenosAires).build();
        Localidad laPlata = Localidad.builder().id(5L).nombre("La Plata").provincia(buenosAires).build();
        Localidad cordobaCapital = Localidad.builder().id(6L).nombre("Córdoba Capital").provincia(cordoba).build();
        Localidad carlosPaz = Localidad.builder().id(7L).nombre("Villa Carlos Paz").provincia(cordoba).build();

        Domicilio domicilioCaba = new Domicilio(1L, "Av. Corrientes", 1234, 1000, caba, 5, 2);
        Domicilio domicilioLaPlata = new Domicilio(2L, "Calle 12", 456, 1900, laPlata, 3, 1);
        Domicilio domicilioCordobaCapital = new Domicilio(3L, "Av. Colón", 789, 5000, cordobaCapital, 1, 0);
        Domicilio domicilioCarlosPaz = new Domicilio(4L, "San Martín", 321, 5152, carlosPaz, 2, 3);

        /**Sucursales**/
        Sucursal sucursal1 = Sucursal.builder().nombre("Sucursal CABA").domicilio(domicilioCaba).horarioApertura(LocalTime.of(9, 0)).horarioCierre(LocalTime.of(18, 0)).esCasaMatriz(true).build();
        Sucursal sucursal2 = Sucursal.builder().nombre("Sucursal La Plata").domicilio(domicilioLaPlata).horarioApertura(LocalTime.of(9, 0)).horarioCierre(LocalTime.of(17, 0)).esCasaMatriz(false).build();
        Sucursal sucursal3 = Sucursal.builder().nombre("Sucursal Córdoba Capital").domicilio(domicilioCordobaCapital).horarioApertura(LocalTime.of(8, 30)).horarioCierre(LocalTime.of(17, 30)).esCasaMatriz(true).build();
        Sucursal sucursal4 = Sucursal.builder().nombre("Sucursal Carlos Paz").domicilio(domicilioCarlosPaz).horarioApertura(LocalTime.of(10, 0)).horarioCierre(LocalTime.of(18, 0)).esCasaMatriz(false).build();

        sucursalRepo.save(sucursal1);
        sucursalRepo.save(sucursal2);
        sucursalRepo.save(sucursal3);
        sucursalRepo.save(sucursal4);

        /**Empresas**/
        Empresa empresa1 = Empresa.builder().nombre("Empresa1").razonSocial("Empresa Uno S.A.").cuit(30500123).cuil(20305001234L).logo("logo1.png").build();
        empresa1.agregarSucursal(sucursal1);
        empresa1.agregarSucursal(sucursal2);
        empresaRepo.save(empresa1);

        Empresa empresa2 = Empresa.builder().nombre("Empresa2").razonSocial("Empresa Dos S.A.").cuit(30600234).cuil(20306002345L).logo("logo2.png").build();
        empresa2.agregarSucursal(sucursal3);
        empresa2.agregarSucursal(sucursal4);
        empresaRepo.save(empresa2);

        /**Categorías y unidades**/
        Categoria pizzas = Categoria.builder().denominacion("Pizzas").esInsumo(false).build();
        Categoria sandwiches = Categoria.builder().denominacion("Sandwiches").esInsumo(false).build();
        Categoria insumos = Categoria.builder().denominacion("Insumos").esInsumo(true).build();
        categoriaRepo.save(pizzas);
        categoriaRepo.save(sandwiches);
        categoriaRepo.save(insumos);

        UnidadMedida kg = UnidadMedida.builder().denominacion("Kg").build();
        UnidadMedida litro = UnidadMedida.builder().denominacion("Litro").build();
        UnidadMedida gramos = UnidadMedida.builder().denominacion("Gramos").build();
        unidadRepo.save(kg);
        unidadRepo.save(litro);
        unidadRepo.save(gramos);

        /**Insumos**/
        ArticuloInsumo sal = ArticuloInsumo.builder().denominacion("Sal").precioCompra(1.0).stockActual(100).stockMinimo(10).stockMaximo(200).esParaElaborar(true).unidadMedida(gramos).categoria(insumos).build();
        ArticuloInsumo harina = ArticuloInsumo.builder().denominacion("Harina").precioCompra(0.5).stockActual(50).stockMinimo(5).stockMaximo(100).esParaElaborar(true).unidadMedida(kg).categoria(insumos).build();
        ArticuloInsumo aceite = ArticuloInsumo.builder().denominacion("Aceite").precioCompra(3.0).stockActual(30).stockMinimo(3).stockMaximo(60).esParaElaborar(true).unidadMedida(litro).categoria(insumos).build();
        ArticuloInsumo carne = ArticuloInsumo.builder().denominacion("Carne").precioCompra(5.0).stockActual(20).stockMinimo(2).stockMaximo(40).esParaElaborar(true).unidadMedida(kg).categoria(insumos).build();
        insumoRepo.save(sal);
        insumoRepo.save(harina);
        insumoRepo.save(aceite);
        insumoRepo.save(carne);

        /**Manufacturados**/
        ArticuloManufacturado pizza = ArticuloManufacturado.builder()
                .denominacion("Pizza Hawaina")
                .precioVenta(12.0)
                .descripcion("Pizza con piña y jamón")
                .tiempoEstimadoMinutos(20)
                .preparacion("Hornear por 20 minutos")
                .categoria(pizzas)
                .unidadMedida(kg)
                .articuloManufacturadoDetalles(Set.of(
                        ArticuloManufacturadoDetalle.builder().cantidad(1).articuloInsumo(sal).build(),
                        ArticuloManufacturadoDetalle.builder().cantidad(2).articuloInsumo(harina).build(),
                        ArticuloManufacturadoDetalle.builder().cantidad(1).articuloInsumo(aceite).build()
                ))
                .build();

        ArticuloManufacturado lomo = ArticuloManufacturado.builder()
                .denominacion("Lomo Completo")
                .precioVenta(15.0)
                .descripcion("Lomo completo con todos los ingredientes")
                .tiempoEstimadoMinutos(25)
                .preparacion("Cocinar a la parrilla por 25 minutos")
                .categoria(sandwiches)
                .unidadMedida(kg)
                .articuloManufacturadoDetalles(Set.of(
                        ArticuloManufacturadoDetalle.builder().cantidad(1).articuloInsumo(sal).build(),
                        ArticuloManufacturadoDetalle.builder().cantidad(1).articuloInsumo(aceite).build(),
                        ArticuloManufacturadoDetalle.builder().cantidad(2).articuloInsumo(carne).build()
                ))
                .build();

        manufacturadoRepo.save(pizza);
        manufacturadoRepo.save(lomo);

        /** Asociar artículos a sucursales **/
        sucursalArticuloRepo.save(SucursalArticulo.builder()
                .sucursal(sucursal1)
                .articulo(pizza)
                .stock(10)
                .precioLocal(13.0)
                .activo(true)
                .observaciones("Promoción 2x1")
                .build());

        sucursalArticuloRepo.save(SucursalArticulo.builder()
                .sucursal(sucursal2)
                .articulo(lomo)
                .stock(5)
                .precioLocal(16.0)
                .activo(true)
                .observaciones("Disponible solo fines de semana")
                .build());

        /**Mostrar artículos por sucursal**/
        System.out.println("\nArtículos disponibles por sucursal:");
        for (Sucursal sucursal : sucursalRepo.findAll()) {
            System.out.println("Sucursal: " + sucursal.getNombre());
            sucursalArticuloRepo.findAll().stream()
                    .filter(sa -> sa.getSucursal().equals(sucursal))
                    .forEach(sa -> System.out.println("  - " + sa.getArticulo().getDenominacion() + " | Stock: " + sa.getStock() + " | Precio: $" + sa.getPrecioLocal()));
        }
    }
}